import sys
from numpy import *

arr = []
inp = open ("pcca/sets.ascii","r")

#read line into array 
for line in inp.readlines():
    # add a new sublist
    arr.append([])
    # loop over the elemets, split by whitespace
    for i in line.split():
        # convert to integer and append to the last
        # element of the list
        arr[-1].append(int(i))
lengths = []
for i in range(len(arr)):
	lengths.append(len(arr[i]))
min_index =lengths.index(min(lengths)) 
max_index =lengths.index(max(lengths)) 
set_a = array(arr[min_index])
set_b = array(arr[max_index])
set_a = set_a.reshape(1,len(set_a))
set_b = set_b.reshape(1,len(set_b))
savetxt("tpt/setA.ascii", set_a,fmt="%d")
savetxt("tpt/setB.ascii", set_b,fmt="%d")


