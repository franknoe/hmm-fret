#!/bin/bash
rm ./modeltrajectories/*.traj
rm ./discretized/*.disctraj
rm ./discretized/clusterCenters.dat
rm ./matrix/countmatrixOf_Traj1_Traj2.ascii
rm ./matrix/transitionmatrixOf_Traj1_Traj2.ascii
rm ./chapman/result.ascii
rm ./its/result.its
rm ./pcca/fuzzy.ms
rm ./pcca/crisp.ms
rm ./pcca/sets.ascii
rm ./tpt/*
rm ./emma.log
rm ./*.ascii
