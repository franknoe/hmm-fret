#!/bin/bash
#removes all gnuplot generated plots
rm *.png