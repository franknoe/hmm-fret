from numpy import *
import os
import re
from matplotlib import rc
import matplotlib.pyplot as p

rc('text', usetex=True)
rc('font', family='ComputerModern', size='14')

nfigures=0

def plot_timescales(folder):
   global nfigures
   data=genfromtxt(folder+"/timescales.dat")
   lagtimes=data[:,0]
   timescales=data[:,1:]
   ntimescales=shape(timescales)[1]
   p.figure(nfigures)
   nfigures+=1
   p.title("Implied timescales")
   p.subplot(111)
   p.xlabel(r"$\tau$ in elementary timesteps $\mathrm{d}t$  of trajectory")
   p.ylabel(r"$t_{i}(\tau)$ $[\mathrm{d}t]$")
   for i in arange(ntimescales):
      p.plot(lagtimes, timescales[:,i])
   p.grid(True)
   p.savefig(folder+'/timescales.eps')
   

def plot_chapman_kolmogorov(folder):
   global nfigures
   """Find all files with name chapman_kolmogorov*.dat in folder """
   files=os.listdir(folder)
   pattern="^(chapman_kolmogorov).*(\.dat)$"
   matcher=re.compile(pattern)
   chapman_files=[]
   for s in files:
      if(matcher.match(s)):
         chapman_files.append(s)
   nsets=len(chapman_files)
   data=genfromtxt(folder+"/"+chapman_files[0])
   ntimesteps=shape(data)[0]
   times=zeros((ntimesteps,nsets))
   model=zeros((ntimesteps,nsets))
   trajectory=zeros((ntimesteps,nsets))
   error=zeros((ntimesteps,nsets))
   for i in arange(len(chapman_files)):
      data=genfromtxt(folder+"/"+chapman_files[i])
      times=data[:,0]
      model=data[:,1]
      trajectory=data[:,2]
      error=data[:,3]
      p.figure(nfigures)
      nfigures+=1
      p.title("Chapman-Kolmogorov test")      
      p.subplot(111)
      p.xlabel(r"$t$ in elementary timesteps $\mathrm{d}t$  of trajectory")
      p.ylabel(r"$||\pi^T(T^k(\tau)-T(k \tau))||_{S_i}$")
      p.errorbar(times,trajectory,yerr=error)
      p.plot(times, model)
      p.savefig(folder+"/"+os.path.splitext(chapman_files[i])[0]+".eps")

def plot_eigenvalues(folder):
   global nfigures
   data=genfromtxt(folder+"/eigenvalues.dat")
   p.figure(nfigures)
   nfigures+=1
   p.title("Eigenvalues")
   p.xlabel(r"$i$")
   p.ylabel(r"$\lambda_i$")
   p.subplot(111)
   p.plot(arange(len(data)), data, marker='o', linestyle='')
   p.savefig(folder+"/eigenvalues.eps")

def plot_eigenvalues_sampled(folder):
   global nfigures
   data=genfromtxt(folder+"/sampling/eigenvalues.dat")
   p.figure(nfigures)
   nfigures+=1
   p.title("Eigenvalues")
   p.xlabel(r"$i$")
   p.ylabel(r"$\lambda_i$")
   p.subplot(111)
   p.errorbar(arange(len(data)), data[:,0], yerr=data[:,1], marker='o')
   p.savefig(folder+"/sampling/eigenvalues.eps")

def plot_stationary_distribution(folder):
   global nfigures
   data=genfromtxt(folder+"/stationary_distribution.dat")
   p.figure(nfigures)
   nfigures+=1
   p.title("Stationary distribution")
   p.subplot(111)
   p.xlabel(r"Microstate $i$")
   p.ylabel(r"$\pi_i$")
   p.plot(arange(len(data)), data, marker='o')
   p.savefig(folder+"/stationary_distribution.eps")

if __name__=="__main__":
   clustering="regspatial"
   folder="./"+clustering
   #timescales="./"+clustering+"/timescales.dat"
   chapman_kolmogorov="./"+clustering+"/chapman_kolmogorov.dat"
   plot_timescales(folder)
   plot_chapman_kolmogorov(folder)
   plot_eigenvalues(folder)
   plot_stationary_distribution(folder)
   plot_eigenvalues_sampled(folder)
   
