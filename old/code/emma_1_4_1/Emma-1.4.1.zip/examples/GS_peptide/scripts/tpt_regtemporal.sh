#!/bin/bash

# tpt coarse grained on pcca sets. Choose sets A and B from the pcca output (e.g. A = least populated, B = most populated set)
echo "Trying to run transition path theory analysis on sets provided"
../../../bin/mm_tpt -inputtransitionmatrix ../results/T.dat -seta ../results/A.dat -setb ../results/B.dat -onetflux ../results/tpt-flux.dat -oforwardcommittor ../results/tpt-committor.dat

echo "Coarse-grained TPT"
../../../bin/mm_tpt -inputtransitionmatrix ../results/T.dat -seta ../results/A.dat -setb ../results/B.dat -coarsesets ../results/pcca4.sets -ocoarsenetflux ../results/tpt-coarse-flux.dat -ocoarseforwardcommittor ../results/tpt-coarse-committor.dat
