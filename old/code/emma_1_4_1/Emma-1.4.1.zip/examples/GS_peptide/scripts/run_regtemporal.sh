#!/bin/bash
#defining some path variables
emma_bin="../../../bin"
export emma_bin

results="../results/regtemporal"
export results

trajectories="../data"

discretized_trajectories="${results}"
cluster_centers="${results}/clusterCenters.dcd"
export cluster_centers
connected_sets="${results}/connected_sets.dat"
implied_timescales="${results}/timescales.dat"
transitionmatrix="${results}/transitionmatrix.dat"
countmatrix = "${results}/countmatrix.dat"
export transitionmatrix
countmatrix="${results}/countmatrix.dat"
pcca_sets="${results}/pcca_sets.dat"
chapman_kolmogorov="${results}/chapman_kolmogorov"
eigenvalues="${results}/eigenvalues.dat"
stationary_distribution="${results}/stationary_distribution.dat"
eigenvectors_left="${results}/eigenvectors_left.dat"
eigenvectors_right="${results}/eigenvectors_right.dat"

echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "This is a script demonstrating the capabilities of the software package EMMA, for the analysis of MR121-GSGS-W peptide"
echo "-> Input *.xtc trajectories can be downloaded from SimTk and should be located in ../data"
echo "-> All output files will be found in ../results"
echo "starting run............"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo " "
echo " "

# calculating the cluster centers
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "   +Calculating cluster centers using rmsd metric and regular temporal spacing spacing"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

../../../bin/mm_cluster -i ${trajectories}/*.xtc -algorithm  regulartemporal -spacing 10000 -metric minrmsd -o ${cluster_centers}
#assigning cluster centers to input trajectories
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "   +Assigning cluster centers to the input trajectories. "
echo "   +The assignment of 800000 frames to 400 clusters requires 320,000,000 mininmal RMSD calculations in 24 coordinates, this may take some time...  "
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

../../../bin/mm_assign -i ${trajectories}/*.xtc -ic ${cluster_centers} -metric minrmsd -o ${results}

#connectivity test
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "   +Looking at connectivity of the clusters.."
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

../../../bin/mm_connectivity -i ${results}/*.disctraj -o ${connected_sets}

# Implied timescales
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "   +Calculating implied timescales with the first 10 dominant eigenvalues"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

../../../bin/mm_timescales -i ${results}/*.disctraj -sampling slidingwindow -neig 10 -lagtimes 1 2 4 8 16 32 64 128 256 400 500 600 800 1000 1250 1500 -restrictToStates ${connected_sets} -o ${implied_timescales}

# Select tau = 10 ns. Count and transition matrix estimation:
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "   +estimating count and transition matrix"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

../../../bin/mm_estimate -i ${results}/*.disctraj -lagtime 1000 -sampling slidingwindow -outputcountmatrix ${countmatrix} -outputtransitionmatrix  ${transitionmatrix}

# pcca
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "   +pcca, selecting metastable sets"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

../../../bin/mm_pcca -inputtransitionmatrix ${transitionmatrix} -nclusters 4 -osets ${pcca_sets}

# chapman-kolmogorow test
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "   +chapman-kolmogorow test" 
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

../../../bin/mm_chapman -i ${results}/*disctraj -inputtransitionmatrix ${transitionmatrix} -sets ${pcca_sets} -dtT 10 -dtTraj 0.01 -kmax 10 -o ${chapman_kolmogorov}

# spectral analysis
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "   +spectral analysis"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
./${emma_bin}/mm_transitionmatrixAnalysis -inputtransitionmatrix ${transitionmatrix} -nev 10 -eigenvalues ${eigenvalues} -stationarydistribution ${stationary_distribution} -lefteigenvectors ${eigenvectors_left} -righteigenvectors ${eigenvectors_right}


echo "In order to now run mm_tpt set A and set B must be defined from the pcca result. This needs to be done manually Use A = set 2 (least populated) and B = set 1 (most populated) "


 
