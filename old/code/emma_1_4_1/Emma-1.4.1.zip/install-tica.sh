python setup.py install --install-lib=.
