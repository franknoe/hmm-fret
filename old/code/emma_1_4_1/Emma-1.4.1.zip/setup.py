from distutils.core import setup, Extension
import numpy
 
cocovar_module = Extension('cocovar', sources = ['cocovar.c'])
 
setup (name = 'cocovar',
        version = '0.2',
        description = 'Correlations Corvariances',
        include_dirs = [numpy.get_include()],  
        ext_modules = [cocovar_module])
